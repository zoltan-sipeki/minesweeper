package aknakereso;


import java.sql.*;

public class Db {

	private Connection con;
	
	public Db() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost/aknakereso","root","");
			System.out.println("Sikeres csatlakoz�s");
			System.out.println(con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Connection getCon() {
		return con;
	}
	
	public ResultSet lekerdez(String sql) {
		
		ResultSet rs = null;
		Statement stm = null;
		
		try {
			stm = (Statement)con.createStatement();
			rs = stm.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
}
