# **Kiaknázva** #
Ez a játék egy aknakereső logikai játék. A játék lényege a mezőn lévő összes akna megtalálása, pontosabban elkerülése.
A játék mezőinek és bombáinak száma a nehézségi szinttől (Könnyű, Közepes, Nehéz) függ. A bal egérgombbal kattintva egy üres mezőre az megjeleníti, hogy bombára léptünk-e vagy sem.
A jobb gomb lenyomásával megjelölhetjük az általunk veszélyesnek vélt mezőket, így elkerülhetjük az aknákat.
A különböző számok azt mutatják, hogy a szomszédos mezőkön hány darab akna található.
Ez a játék a *Debreceni Egyetem Informatikai Kar* levelezős hallgatói által készült a *Szoftverfejlesztési módszertanok* nevű tárgyra.
## **A projekt tagjai:** ##
- Bartha Máté
- Sipeki Zoltán
- Ignéczi Tibor
